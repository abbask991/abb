
import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from prophet import Prophet
import yfinance as yf

st.title("📈 Gold Price Forecasting Dashboard")

# تحميل البيانات
df = yf.download("GC=F", start="2020-01-01")
df = df.reset_index()[['Date', 'Close']]
df.columns = ['ds', 'y']

# تدريب نموذج Prophet
model = Prophet()
model.fit(df)

# توقع 30 يوم قدام
future = model.make_future_dataframe(periods=30)
forecast = model.predict(future)

# رسم المخطط
fig = go.Figure()
fig.add_trace(go.Scatter(x=df['ds'], y=df['y'], name="Actual Price"))
fig.add_trace(go.Scatter(x=forecast['ds'], y=forecast['yhat'], name="Forecast"))
st.plotly_chart(fig)

# جدول التوقع
st.subheader("📊 Forecast Table (Next 30 Days)")
st.dataframe(forecast[['ds', 'yhat']].tail(30))
